#pragma once
#include "Array.h"
#include "Decimal.h"
#include "Octal.h"
class Application
{
public:
	void Run();
};