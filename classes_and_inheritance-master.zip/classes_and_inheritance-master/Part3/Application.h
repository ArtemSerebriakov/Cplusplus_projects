#pragma once
#include "Integer.h"
#include "Decimal.h"
#include "Binary.h"
class Application
{
public:
	void Run();
}